# Sarcasm_Detection_with_streamlit_App 😉
<img src="https://c.tenor.com/YjOqqxOJ6JMAAAAM/sarcasm-big-bang-theory.gif"> 
<h3>Weekend project</h3>
<p>This project is about detecting whether a given sentence or text is sarcasm or not. I created Win Simple ANN and K-fold CV not so fancy. It gave me 96% in train and 91% in test. It was quite good For Ann, I made a Data App with Streamlit as a Fun Sunday Project.</p>
